# runtime-style-invalidation-diagnostics benchmark report

- Generated: 2026-09-08T16:25:19.459Z
- Environment: darwin 25.6.0 arm64, Node v24.20.0
- CPU: Apple M3 Max (16)
- Browser: Chromium 153.0.8010.12

## Packages

| Package | Version |
|---|---|
| @master/css | workspace:^ |
| @master/css-runtime | workspace:^ |
| @master/css-server | workspace:^ |
| @master/css-preset | workspace:^ |
| @tailwindcss/cli | ^4.3.3 |
| @playwright/test | 1.63.0 |

## Summary

| Variant | Metric | Median | Mean | Min | Max | Samples |
|---|---|---:|---:|---:|---:|---:|
| stress-dom / Master CSS static / static cleanup baseline | Mutation to ready | 959 ms | 959 ms | 959 ms | 959 ms | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Style recalculation | 12.882 ms | 12.882 ms | 12.882 ms | 12.882 ms | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Layout | 24.999 ms | 24.999 ms | 24.999 ms | 24.999 ms | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Paint | 92.334 ms | 92.334 ms | 92.334 ms | 92.334 ms | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Long tasks | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Runtime ensure/delete total | 0 ms | 0 ms | 0 ms | 0 ms | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Runtime ensure class rules duration | 0 ms | 0 ms | 0 ms | 0 ms | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Runtime delete class rules duration | 0 ms | 0 ms | 0 ms | 0 ms | 1 |
| stress-dom / Master CSS static / static cleanup baseline | MutationObserver callbacks | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | MutationObserver callback duration | 0 ms | 0 ms | 0 ms | 0 ms | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Mutation records | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Runtime rule delta | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Preseeded runtime rules | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Seeded retained classes | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Seeded retained rules | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Seeded retained bytes | 0 B | 0 B | 0 B | 0 B | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Retained set adds | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Retained set deletes | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Retained set clears | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Observer paused | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Runtime stylesheet rules before | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Runtime stylesheet rules after trace | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Runtime stylesheet rules after flush | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Runtime utility count before | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Runtime utility count after trace | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Runtime utility count after flush | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Retained classes before | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Retained classes after trace | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Retained classes after flush | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Retained rules after flush | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Retained bytes after flush | 0 B | 0 B | 0 B | 0 B | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Forced retained cleanup classes | 0 count | 0 count | 0 count | 0 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Forced retained cleanup duration | 0 ms | 0 ms | 0 ms | 0 ms | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Computed style valid | 1 count | 1 count | 1 count | 1 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Cleanup valid | 1 count | 1 count | 1 count | 1 count | 1 |
| stress-dom / Master CSS static / static cleanup baseline | Progressive adopted | 0 count | 0 count | 0 count | 0 count | 1 |

## Limits

- This suite is diagnostic-only and does not publish public benchmark claims.
- The dynamic and stress-dom fixtures use the interaction-cost mutation-cleanup-cycle page harness.
- Runtime/progressive variants are measured with benchmark-injected instrumentation; @master/css-runtime source behavior is not changed by this suite.
- Observer-paused variants intentionally disconnect the runtime MutationObserver inside the benchmark page only.
- Retained-volume variants seed inactive generated rules into runtime state to isolate retained stylesheet volume cost.
- Trace-derived event names can change across Chromium versions; raw trace artifacts are kept for review before optimization work.
